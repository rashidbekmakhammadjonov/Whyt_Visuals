package com.whyt.visuals.setting;

public class Setting {
    public enum Type { BOOL, NUM, MODE }

    public final String name;
    public final Type type;
    public double value;
    public final double min, max, step;
    public final String[] modes;

    private Setting(String name, Type type, double value, double min, double max, double step, String[] modes) {
        this.name = name; this.type = type; this.value = value;
        this.min = min; this.max = max; this.step = step; this.modes = modes;
    }

    public static Setting bool(String name, boolean v) {
        return new Setting(name, Type.BOOL, v ? 1 : 0, 0, 1, 1, null);
    }

    public static Setting num(String name, double v, double min, double max, double step) {
        return new Setting(name, Type.NUM, v, min, max, step, null);
    }

    public static Setting mode(String name, String... modes) {
        return new Setting(name, Type.MODE, 0, 0, modes.length - 1, 1, modes);
    }

    public boolean bool() { return value >= 0.5; }
    public double num() { return value; }
    public int intVal() { return (int) Math.round(value); }
    public int modeIndex() { return intVal(); }
    public String mode() { return modes[Math.max(0, Math.min(modes.length - 1, intVal()))]; }

    public void set(double v) {
        double c = Math.max(min, Math.min(max, v));
        if (type == Type.NUM && step > 0) c = Math.round(c / step) * step;
        this.value = c;
    }

    public void toggle() { value = bool() ? 0 : 1; }
    public void cycle() { value = (intVal() + 1) % modes.length; }

    public String display() {
        return switch (type) {
            case BOOL -> bool() ? "ON" : "OFF";
            case MODE -> mode();
            case NUM -> step >= 1 ? String.valueOf(intVal()) : String.format(java.util.Locale.ROOT, "%.1f", value);
        };
    }
}
