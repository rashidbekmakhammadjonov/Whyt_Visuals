package com.whyt.visuals.util;

import net.minecraft.client.gui.DrawContext;

public final class Render {
    private Render() {}

    public static int alpha(int rgb, int a) { return (a << 24) | (rgb & 0xFFFFFF); }

    /** Filled rectangle with 1px clipped corners. */
    public static void roundedBox(DrawContext c, int x, int y, int w, int h, int argb) {
        c.fill(x + 1, y, x + w - 1, y + h, argb);
        c.fill(x, y + 1, x + 1, y + h - 1, argb);
        c.fill(x + w - 1, y + 1, x + w, y + h - 1, argb);
    }
}
