package com.whyt.visuals.module;

import com.whyt.visuals.setting.Setting;
import com.whyt.visuals.util.Render;
import com.whyt.visuals.util.Theme;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class Info extends HudModule {
    private final Setting coords = add(Setting.bool("Coordinates", true));
    private final Setting speed = add(Setting.bool("Speed (BPS)", true));
    private final Setting ping = add(Setting.bool("Ping", true));
    private final Setting direction = add(Setting.bool("Direction", true));

    public Info() { super("Info", "Coordinates, speed, ping", 6, 28); setEnabled(true); }

    @Override
    public void onRender(DrawContext ctx) {
        if (mc.player == null) return;
        List<String> lines = new ArrayList<>();
        var p = mc.player;
        if (coords.bool()) lines.add(String.format(Locale.ROOT, "XYZ  %.1f  %.1f  %.1f", p.getX(), p.getY(), p.getZ()));
        if (direction.bool()) lines.add("Facing  " + p.getHorizontalFacing().asString());
        if (speed.bool()) {
            double bps = Math.hypot(p.getX() - p.prevX, p.getZ() - p.prevZ) * 20.0;
            lines.add(String.format(Locale.ROOT, "Speed  %.2f b/s", bps));
        }
        if (ping.bool() && mc.getNetworkHandler() != null) {
            var e = mc.getNetworkHandler().getPlayerListEntry(p.getUuid());
            if (e != null) lines.add("Ping  " + e.getLatency() + " ms");
        }
        if (lines.isEmpty()) return;

        var tr = mc.textRenderer;
        int w = 0;
        for (String s : lines) w = Math.max(w, tr.getWidth(s));
        w += 12;
        int x = x(), y = y(), h = lines.size() * 11 + 6;
        Render.roundedBox(ctx, x, y, w, h, 0xB0101014);
        ctx.fill(x, y + 1, x + 1, y + h - 1, Theme.accent());
        int ty = y + 4;
        for (String s : lines) {
            ctx.drawTextWithShadow(tr, s, x + 6, ty, 0xFFFFFFFF);
            ty += 11;
        }
    }
}
