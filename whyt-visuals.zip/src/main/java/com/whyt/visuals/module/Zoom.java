package com.whyt.visuals.module;

import com.whyt.visuals.WhytVisuals;
import com.whyt.visuals.setting.Setting;

public class Zoom extends Module {
    private final Setting fov = add(Setting.num("Zoom FOV", 30, 30, 70, 1));
    private boolean zooming;
    private int saved;

    public Zoom() { super("Zoom", "Hold C to zoom in", Category.RENDER); setEnabled(true); }

    @Override
    public void onTick() {
        boolean held = WhytVisuals.zoomKey != null && WhytVisuals.zoomKey.isPressed();
        if (held && !zooming) {
            saved = mc.options.getFov().getValue();
            zooming = true;
        }
        if (zooming && held) {
            mc.options.getFov().setValue(Math.max(30, fov.intVal()));
        } else if (zooming) {
            restore();
        }
    }

    private void restore() {
        mc.options.getFov().setValue(saved);
        zooming = false;
    }

    @Override
    public void onDisable() { if (zooming) restore(); }
}
