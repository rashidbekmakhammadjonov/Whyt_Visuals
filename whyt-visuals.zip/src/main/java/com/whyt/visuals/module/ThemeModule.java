package com.whyt.visuals.module;

import com.whyt.visuals.setting.Setting;

public class ThemeModule extends Module {
    public final Setting rainbow = add(Setting.bool("Rainbow", true));
    public final Setting hue = add(Setting.num("Hue", 200, 0, 360, 1));
    public final Setting speed = add(Setting.num("Speed", 5, 1, 20, 1));

    public ThemeModule() {
        super("Theme", "Accent color used by the HUD and GUI", Category.CLIENT);
        enabled = true;
    }

    @Override public void toggle() { /* theme is always active */ }
}
