package com.whyt.visuals.gui;

import com.whyt.visuals.WhytVisuals;
import com.whyt.visuals.module.Category;
import com.whyt.visuals.module.Module;
import com.whyt.visuals.setting.Setting;
import com.whyt.visuals.util.Config;
import com.whyt.visuals.util.Render;
import com.whyt.visuals.util.Theme;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class ClickGuiScreen extends Screen {
    private static final int W = 118, HEADER = 18, ROW = 15, SROW = 14;

    private static class Panel {
        final Category cat;
        final List<Module> modules;
        int x, y;
        Panel(Category cat, List<Module> modules, int x, int y) { this.cat = cat; this.modules = modules; this.x = x; this.y = y; }
    }

    private interface RowVisitor { void row(Module m, Setting s, int x, int y, int w, int h); }

    private static final List<Panel> PANELS = new ArrayList<>();

    private Panel dragPanel;
    private int dragDx, dragDy;
    private Setting dragSetting;
    private int dragSettingX, dragSettingW;

    public ClickGuiScreen() {
        super(Text.literal("Whyt Visuals"));
        if (PANELS.isEmpty()) {
            int x = 20;
            for (Category c : Category.values()) {
                PANELS.add(new Panel(c, WhytVisuals.modules.in(c), x, 24));
                x += W + 10;
            }
        }
    }

    @Override public boolean shouldPause() { return false; }

    private void layout(Panel p, RowVisitor v) {
        int y = p.y + HEADER;
        for (Module m : p.modules) {
            v.row(m, null, p.x, y, W, ROW);
            y += ROW;
            if (m.expanded) {
                for (Setting s : m.settings) {
                    v.row(m, s, p.x, y, W, SROW);
                    y += SROW;
                }
            }
        }
    }

    private int panelHeight(Panel p) {
        int[] h = {HEADER};
        layout(p, (m, s, x, y, w, hh) -> h[0] += hh);
        return h[0];
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        ctx.fill(0, 0, width, height, 0x70000000);
        var tr = textRenderer;
        ctx.drawTextWithShadow(tr, "Whyt Visuals", 20, 8, Theme.accent());
        ctx.drawTextWithShadow(tr, "Left click: toggle   Right click: settings   Drag header to move",
            20 + tr.getWidth("Whyt Visuals") + 10, 8, 0xFF8A8A94);

        for (Panel p : PANELS) {
            int ph = panelHeight(p);
            Render.roundedBox(ctx, p.x, p.y, W, ph, 0xE0141418);
            ctx.fill(p.x + 1, p.y, p.x + W - 1, p.y + HEADER, 0xFF1C1C22);
            ctx.fill(p.x + 1, p.y + HEADER - 1, p.x + W - 1, p.y + HEADER, Theme.accent());
            ctx.drawTextWithShadow(tr, p.cat.label, p.x + 6, p.y + 5, 0xFFFFFFFF);

            layout(p, (m, s, x, y, w, h) -> {
                boolean hover = mx >= x && mx < x + w && my >= y && my < y + h;
                if (s == null) {
                    if (m.enabled) ctx.fill(x + 1, y, x + w - 1, y + h, Render.alpha(Theme.accent(y), 0x60));
                    else if (hover) ctx.fill(x + 1, y, x + w - 1, y + h, 0x30FFFFFF);
                    ctx.drawTextWithShadow(tr, m.name, x + 6, y + 4, m.enabled ? 0xFFFFFFFF : 0xFFB0B0BA);
                    if (!m.settings.isEmpty()) ctx.drawTextWithShadow(tr, m.expanded ? "-" : "+", x + w - 11, y + 4, 0xFF8A8A94);
                    if (hover) hoverText = m.description;
                } else {
                    ctx.fill(x + 1, y, x + w - 1, y + h, 0x40000000);
                    if (s.type == Setting.Type.NUM) {
                        double f = (s.value - s.min) / (s.max - s.min);
                        ctx.fill(x + 4, y + h - 3, x + 4 + (int) ((w - 8) * f), y + h - 1, Theme.accent(y));
                    }
                    ctx.drawTextWithShadow(tr, s.name, x + 8, y + 3, 0xFFD0D0D8);
                    String d = s.display();
                    int col = s.type == Setting.Type.BOOL ? (s.bool() ? Theme.accent() : 0xFF8A8A94) : 0xFFFFFFFF;
                    ctx.drawTextWithShadow(tr, d, x + w - 6 - tr.getWidth(d), y + 3, col);
                }
            });
        }
        if (hoverText != null) {
            int tw = tr.getWidth(hoverText);
            Render.roundedBox(ctx, mx + 8, my + 8, tw + 8, 14, 0xF0101014);
            ctx.drawTextWithShadow(tr, hoverText, mx + 12, my + 11, 0xFFFFFFFF);
            hoverText = null;
        }
    }

    private String hoverText;

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        // Iterate topmost-last so the last drawn panel gets the click first.
        for (int i = PANELS.size() - 1; i >= 0; i--) {
            Panel p = PANELS.get(i);
            if (mx >= p.x && mx < p.x + W && my >= p.y && my < p.y + HEADER) {
                dragPanel = p; dragDx = (int) mx - p.x; dragDy = (int) my - p.y;
                PANELS.remove(i); PANELS.add(p);
                return true;
            }
            boolean[] handled = {false};
            layout(p, (m, s, x, y, w, h) -> {
                if (handled[0] || mx < x || mx >= x + w || my < y || my >= y + h) return;
                handled[0] = true;
                if (s == null) {
                    if (button == 0) m.toggle();
                    else if (button == 1 && !m.settings.isEmpty()) m.expanded = !m.expanded;
                } else if (button == 0 || button == 1) {
                    switch (s.type) {
                        case BOOL -> s.toggle();
                        case MODE -> s.cycle();
                        case NUM -> { dragSetting = s; dragSettingX = x + 4; dragSettingW = w - 8; applySlider(mx); }
                    }
                }
            });
            if (handled[0]) return true;
        }
        return super.mouseClicked(mx, my, button);
    }

    private void applySlider(double mx) {
        if (dragSetting == null) return;
        double f = Math.max(0, Math.min(1, (mx - dragSettingX) / dragSettingW));
        dragSetting.set(dragSetting.min + f * (dragSetting.max - dragSetting.min));
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragPanel != null) {
            dragPanel.x = (int) mx - dragDx;
            dragPanel.y = (int) my - dragDy;
            return true;
        }
        if (dragSetting != null) { applySlider(mx); return true; }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        dragPanel = null;
        dragSetting = null;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key == GLFW.GLFW_KEY_RIGHT_SHIFT || key == GLFW.GLFW_KEY_ESCAPE) {
            close();
            return true;
        }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public void removed() {
        Config.save(WhytVisuals.modules);
    }
}
